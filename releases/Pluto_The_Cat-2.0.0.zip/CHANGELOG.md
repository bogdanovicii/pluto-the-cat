# Changelog

## 2.0.0
- New starting passive **Nine Lives**: the first time a hit would kill Pluto it is cancelled, he stands back up with one heart and loses one of nine lives (per run).
- Cat reflexes: longer dodge roll with 6 of 9 invulnerable frames.
- Royal Kibble Sack: two kibble per pawful, 1-in-20 big chunk, crumbs on the floor top up your other gun's ammo.
- Wet Food Can: lovestruck enemies take 20 % more damage; bosses get a fixed 3 s stun instead of AI-dependent charm; faster recharge.
- Synergies: Complete Feline Nutrition (homing kibble), Dinner Time (longer, wider charm), Laser Pointer (dodge rolls drop a red dot enemies chase), Box Fort (Cardboard Box has no cooldown).
- Alt skin **Wet Pluto** (fresh out of the bath), swapped at the bathtub in the Breach.
- New Breach idles: loaf, groom, and knocking a bowl off a ledge. Co-op death shows Pluto's ghost.
- Logs the Punch-Out sprite names so 2.1 can ship Pluto's boxing sprites.

## 1.0.1
- Fix: character build failed on Alexandria 0.5.10 because the `<altGuns>` block was missing (altGun is NULL). Added it.
- The plugin now reports a failed character build instead of printing "ready".

## 1.0.0
- First release: Pluto the Cat character, Royal Kibble Sack starter gun, Wet Food Can active.
