# Pluto The Cat

Adds **Pluto the Cat** as a new playable Gungeoneer. He is a chunky brown tabby-and-white cat with green eyes, a white blaze, and absolutely no interest in your plans.

## What you get

- **Pluto** in the Breach, selectable like any other Gungeoneer. Slightly faster than the Pilot with a quicker dodge roll.
- **Royal Kibble Sack** (starter gun, infinite ammo): flings dry cat food by the pawful. Kibble bounces once, because kibble always ends up under the fridge. Shooting a secret-room wall cracks it and opens it after a few pawfuls.
- **Wet Food Can** (starter active): throw a tin of the good stuff straight at an enemy. The enemy it hits takes 5 damage and falls in love with Pluto for 10 seconds, fights on his side and takes 20 % more damage; the tin always bursts where it stops (enemy, wall or end of range) and charms every enemy within 2 tiles of the gravy. Bosses are stunned for 3 seconds instead. Recharges after 200 damage.
- **Nine Lives** (starter passive): Pluto has already spent six of his nine lives and starts every run on his seventh. A hit that would kill him is cancelled and the next life begins (one full heart). The ninth life is the last one: no more saves. Configurable (`StartingLife`).
- **Puffed Up** (starter passive): hit Pluto and he bristles for a few seconds, bigger and fuzzier, hitting harder and faster.
- **Cat reflexes**: a longer dodge roll with more invulnerable frames, and he lands on his feet: pits cost no health.
- **Synergies**: Complete Feline Nutrition (kibble homes in with any snack item), Dinner Time (with Charming Rounds, Charm Horn or Yellow Chamber the can's charm lasts twice as long and its gravy splash is 50 % wider), Laser Pointer (dodge rolls leave a red dot enemies chase, with any laser gun), Box Fort (Cardboard Box has no cooldown), Playdate (Coco Blue + Dog: the Dog bites whatever chases decoy Coco), Squire (Coco Blue + Ser Junkan: +1 Coco stuffing per Junkan rank, Junkan charges Coco's chaser) and Knighted (Squire with a Holy Knight Junkan: Coco wears a tin helmet).
- **Coco Blue** (starter companion): Pluto's plush cat follows him, drops a kibble crumb whenever Pluto gets hurt, and stops any enemy bullet that touches him. After eight blocks he is knocked out for a while (pet him to bring him round early). Pet him (interact next to him) for hearts and a burst of speed; pet him during a fight and he goes decoy.
- **Squeaky Toy** (second starter active; Pluto has two active slots, swap with the active-swap key): sends Coco out as a decoy for a few seconds; enemies chase him while he dodges around the room. Pluto can never drop it. It also appears in chests and shops for every other character: pick it up and Coco follows you too, drop it and he leaves.
- **Wet Pluto** alt skin: touch the bathtub just above him in the Breach. Wet Pluto carries the Royal Canin Gravy Pouch instead of the kibble bag.
- Enemies that die while in love sometimes drop a kibble bowl that heals half a heart.

## Install (r2modman)

1. Install BepInExPack_EtG, Mod the Gungeon API and Alexandria (r2modman pulls them in as dependencies).
2. Install this mod from Thunderstore, or Settings → Import local mod → pick the zip.
3. Launch modded. Pluto stands in the Breach with the other Gungeoneers.

## Verify it loaded

Open the console (F2 or the ~ key) and look for `[Pluto] Pluto the Cat is ready. Meow.` If you see `[Pluto] Pluto the Cat failed to load`, the line after it is the error; please report it with your BepInEx log.

## Credits

Character, gun and item art drawn from photos of the real Pluto. Built on Alexandria's CharacterAPI and ItemAPI, modelled on Once More Into The Breach and Lich Items.
