# Pluto The Cat

Adds **Pluto the Cat** as a new playable Gungeoneer. He is a chunky brown tabby-and-white cat with green eyes, a white blaze, and absolutely no interest in your plans.

## What you get

- **Pluto** in the Breach, selectable like any other Gungeoneer. Slightly faster than the Pilot with a quicker dodge roll.
- **Royal Kibble Sack** (starter gun, infinite ammo): flings dry cat food by the pawful. Kibble bounces once, because kibble always ends up under the fridge.
- **Wet Food Can** (starter active): lob a can of the good stuff. Every enemy near where it lands falls in love with Pluto for 10 seconds and fights on his side. Unlike vanilla charm, it also works on bosses.

## Install (r2modman)

1. Install BepInExPack_EtG, Mod the Gungeon API and Alexandria (r2modman pulls them in as dependencies).
2. Install this mod from Thunderstore, or Settings → Import local mod → pick the zip.
3. Launch modded. Pluto stands in the Breach with the other Gungeoneers.

## Verify it loaded

Open the console (F2 or the ~ key) and look for `[Pluto] Pluto the Cat is ready. Meow.` If you see `[Pluto] Pluto the Cat failed to load`, the line after it is the error; please report it with your BepInEx log.

## Credits

Character, gun and item art drawn from photos of the real Pluto. Built on Alexandria's CharacterAPI and ItemAPI, modelled on Once More Into The Breach and Lich Items.
